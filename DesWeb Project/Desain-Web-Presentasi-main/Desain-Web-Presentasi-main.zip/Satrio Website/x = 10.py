

# x = int(input())

#print(type(10))

# 1. Jika kerdusnya ada isinya
# Maka ambil 1 isinya, baru makan

# 0 = Habis
# if x > 0:
#     print("Ada isinya")


# A = input("Mau Lewat Jalan Mana?")

# if A == "kiri":
#     print("Kamu lewat kiri")
# elif A == "kanan":
#     print("Kamu lewat kanan")



# x = input("Apakah lampu rumahmu hidup?")

# if x == "iya":
#     print("Ya, lampu rumahmu hidup!")
# elif x == "tidak":
#     print('Lampu rumahmu mati!')

# k = [10, 20, 3, 4, 5]


# # for i in range(0, 5):
# #     print(i)


# for i in k:
#     print(i)



for i in range(5):
    i += 1
    print("*"*i)




